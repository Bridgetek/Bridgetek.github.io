#!/usr/bin/env python3
"""
make_assets.py: build the EVE Screen Editor projects of the bitmap use-case demos.

Creates, next to this script, one folder per project:

    <Project>/<Project>.ese            ESE project: Content (Raw assets) + Coprocessor display list
    <Project>/resources/*.raw          the RAM_G data, raw bytes, loaded at fixed addresses
    <Project>/overview/overview.json   project description shown by ESE

The overview/<Project>.png thumbnails are pre-rendered and are not rebuilt.

The data is synthetic demo content (a thermal scene, a console screen, a
CAN-bus log, an audio spectrum). A fixed random seed makes every run
reproduce byte-identical output. To change a screen, edit its build_*()
function and run the script again.

Requirements: Python 3.7 or later, NumPy.

    python make_assets.py                         # BT815 projects, in place (as shipped)
    python make_assets.py --device BT881          # BT881 projects, into ./BT881/
    python make_assets.py --device FT813 --out D  # any supported device, into folder D
"""

import argparse
import json
import os
import random
import shutil

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))

W, H = 480, 272             # screen size of all projects
SEED = 7

# ESE device ids. "precision" = BITMAP_TRANSFORM_A/B/D/E take (p, v) [BT81x];
# otherwise they take a single 8.8 value [FT81x, BT88x].
DEVICES = {
    "FT810": (0x810, False), "FT811": (0x811, False), "FT812": (0x812, False), "FT813": (0x813, False),
    "BT880": (0x880, False), "BT881": (0x881, False), "BT882": (0x882, False), "BT883": (0x883, False),
    "BT815": (0x815, True), "BT816": (0x816, True), "BT817": (0x817, True), "BT818": (0x818, True),
}
DEFAULT_DEVICE = "BT815"

# ESE enumerant names, used verbatim as display-list arguments
NEAREST, BILINEAR = "NEAREST", "BILINEAR"
BORDER, REPEAT = "BORDER", "REPEAT"
BITMAPS, LINES, RECTS = "BITMAPS", "LINES", "RECTS"
ZERO, ONE, SRC_ALPHA, DST_ALPHA = "ZERO", "ONE", "SRC_ALPHA", "DST_ALPHA"
ONE_MINUS_SRC_ALPHA, ONE_MINUS_DST_ALPHA = "ONE_MINUS_SRC_ALPHA", "ONE_MINUS_DST_ALPHA"
TEXT8X8, TEXTVGA, BARGRAPH, PALETTED8 = "TEXT8X8", "TEXTVGA", "BARGRAPH", "PALETTED8"

LABEL_DESC = "TEXT8X8 label strings, CP437, 1 byte per character, each 4-byte aligned"

# ----------------------------------------------------------------------------
# RAM_G image and display-list recorder
# ----------------------------------------------------------------------------

class Ram:
    """ RAM_G image. put() places each buffer at the next 4-byte-aligned address. """
    def __init__(self):
        self.mem = bytearray(1 << 20)
        self.ptr = 0
        self.data = []              # (name, addr, size, description)
        self.label0 = None          # address of the first label string

    def put(self, data, name = None, desc = None):
        a = (self.ptr + 3) & ~3
        b = bytes(data)
        self.mem[a:a + len(b)] = b
        self.ptr = a + len(b)
        if name:
            self.data.append((name, a, len(b), desc))
        elif self.label0 is None:
            self.label0 = a
        return a

    def assets(self):
        """ [(name, addr, bytes, description)]: the named buffers, then all labels as one file """
        out = [(n, a, bytes(self.mem[a:a + s]), d) for (n, a, s, d) in self.data]
        if self.label0 is not None:
            out.append(("labels", self.label0, bytes(self.mem[self.label0:self.ptr]), LABEL_DESC))
        return out

class DisplayList:
    """ Records display-list commands, written to ESE as NAME(arg, ...) lines """
    NAMES = {
        "Clear": "CLEAR", "ClearColorRGB": "CLEAR_COLOR_RGB", "ColorRGB": "COLOR_RGB",
        "ColorMask": "COLOR_MASK", "BlendFunc": "BLEND_FUNC", "LineWidth": "LINE_WIDTH",
        "Begin": "BEGIN", "End": "END", "Vertex2ii": "VERTEX2II", "Vertex2f": "VERTEX2F",
        "BitmapHandle": "BITMAP_HANDLE", "BitmapSource": "BITMAP_SOURCE",
        "BitmapLayout": "BITMAP_LAYOUT", "BitmapSize": "BITMAP_SIZE",
        "BitmapTransformA": "BITMAP_TRANSFORM_A", "BitmapTransformC": "BITMAP_TRANSFORM_C",
        "BitmapTransformE": "BITMAP_TRANSFORM_E", "BitmapTransformF": "BITMAP_TRANSFORM_F",
        "PaletteSource": "PALETTE_SOURCE", "ScissorXY": "SCISSOR_XY", "ScissorSize": "SCISSOR_SIZE",
    }

    def __init__(self):
        self.items = []             # ("cmd", NAME, args) or ("note", text)

    def note(self, s):
        self.items.append(("note", s))

    def __getattr__(self, name):
        cmd = self.NAMES[name]
        def emit(*args):
            self.items.append(("cmd", cmd, args))
        return emit

    def lines(self, asset_names, precision):
        out = []
        for it in self.items:
            if it[0] == "note":
                out += ["", "// " + it[1]]
                continue
            _, cmd, args = it
            if cmd in ("BITMAP_TRANSFORM_A", "BITMAP_TRANSFORM_B", "BITMAP_TRANSFORM_D",
                       "BITMAP_TRANSFORM_E") and not precision:
                assert args[0] == 0, "%s: 1.15 precision needs a BT81x device" % cmd
                args = args[1:]                     # FT81x / BT88x form: 8.8 value only
            s = "%s(%s)" % (cmd, ", ".join(str(a) for a in args))
            if cmd == "BITMAP_SOURCE" and args[0] in asset_names:
                s += "    // " + asset_names[args[0]] + ".raw"
            out.append(s)
        return out

# ----------------------------------------------------------------------------
# Shared drawing helpers
# ----------------------------------------------------------------------------

def text8(ram, d, x, y, s, rgb = (255, 255, 255), scale = 1, handle = 15):
    """ One TEXT8X8 label: the string's bytes are the bitmap. Call inside BEGIN(BITMAPS). """
    d.note('TEXT8X8 label "%s"%s' % (s, "  (%dx)" % scale if scale != 1 else ""))
    a = ram.put(s.encode("cp437"))
    n = len(s)
    d.BitmapHandle(handle)
    d.BitmapSource(a)
    d.BitmapLayout(TEXT8X8, n, 1)
    d.BitmapSize(NEAREST, BORDER, BORDER, n * 8 * scale, 8 * scale)
    if scale != 1:
        d.BitmapTransformA(0, 256 // scale)
        d.BitmapTransformE(0, 256 // scale)
    d.ColorRGB(*rgb)
    d.Vertex2f(16 * x, 16 * y)
    if scale != 1:
        d.BitmapTransformA(0, 256)
        d.BitmapTransformE(0, 256)

PAL8_PASSES = [((0, 0, 0, 1), 3),   # (COLOR_MASK r,g,b,a ; palette byte offset)
               ((1, 0, 0, 0), 2),
               ((0, 1, 0, 0), 1),
               ((0, 0, 1, 0), 0)]

def pal8_draw(d, pal, vertices):
    """ Draw each (x, y, handle, cell) as a full-colour PALETTED8 image.
        PALETTED8 yields one palette byte per draw, so draw once per channel. """
    d.note("PALETTED8 4-pass draw: COLOR_MASK picks one channel, PALETTE_SOURCE = palette + byte (A+3 R+2 G+1 B+0)")
    d.BlendFunc(ONE, ZERO)
    for mask, off in PAL8_PASSES:
        d.ColorMask(*mask)
        d.PaletteSource(pal + off)
        for (x, y, h, c) in vertices:
            d.Vertex2ii(x, y, h, c)
    d.ColorMask(1, 1, 1, 1)
    d.BlendFunc(SRC_ALPHA, ONE_MINUS_SRC_ALPHA)

def ramp(stops, n = 256):
    """ Piecewise-linear colour ramp: stops = [(position 0..1, (r,g,b)), ...] -> n x 3 uint8 """
    pos = np.array([p for p, c in stops])
    out = np.zeros((n, 3))
    t = np.linspace(0, 1, n)
    for ch in range(3):
        out[:, ch] = np.interp(t, pos, [c[ch] for p, c in stops])
    return np.round(out).astype(np.uint8)

def smooth(a, k):
    """ Separable box blur, k odd """
    p = k // 2
    for ax in (0, 1):
        b = np.pad(a, [(p, p) if i == ax else (0, 0) for i in range(2)], mode = "edge")
        c = np.cumsum(b, axis = ax)
        c = np.insert(c, 0, 0, axis = ax)
        a = (np.take(c, range(k, c.shape[ax]), axis = ax) - np.take(c, range(0, c.shape[ax] - k), axis = ax)) / k
    return a

# ----------------------------------------------------------------------------
# PALETTED8: handheld thermal camera
# ----------------------------------------------------------------------------

def build_thermal(alarm):
    random.seed(SEED)
    ram, d = Ram(), DisplayList()

    # synthetic 160x120 sensor frame, deg C
    sw, sh = 160, 120
    yy, xx = np.mgrid[0:sh, 0:sw].astype(float)
    T = 21.0 + 2.0 * yy / sh                                                # wall, warmer near floor
    T = np.where((xx > 8) & (xx < 44) & (yy > 8) & (yy < 50), 14.0, T)      # cold window
    T = np.where((yy > 68) & (yy < 82), 46.0, T)                            # steam pipe
    T = np.where(((xx - 52) / 24) ** 2 + ((yy - 100) / 13) ** 2 < 1, 37.0, T)   # pump motor
    T = smooth(T, 5)
    T += 26.0 * np.exp(-(((xx - 112) ** 2 + (yy - 75) ** 2) / (2 * 6.0 ** 2)))   # leaking valve
    T += np.array([random.uniform(-0.3, 0.3) for i in range(sw * sh)]).reshape(sh, sw)
    tmin, tmax = float(T.min()), float(T.max())
    idx = np.round((T - tmin) / (tmax - tmin) * 255).astype(np.uint8)       # 1 byte = temperature
    def temp(i):
        return tmin + i * (tmax - tmin) / 255
    spot = (112, 75)
    tspot = temp(int(idx[spot[1], spot[0]]))

    # palettes: ironbow, and ironbow with an isotherm band above 55 C
    ironbow = ramp([(0.00, (0, 0, 10)), (0.18, (40, 0, 120)), (0.38, (160, 0, 150)),
                    (0.58, (230, 60, 20)), (0.80, (255, 180, 0)), (1.00, (255, 255, 230))])
    iso_t = 55.0
    iso_i = int(np.ceil((iso_t - tmin) / (tmax - tmin) * 255))
    iso = ironbow.copy()
    iso[iso_i:] = (0, 255, 64)
    rgb = iso if alarm else ironbow
    lut = np.zeros((256, 4), dtype = np.uint8)                              # B, G, R, A
    lut[:, 0], lut[:, 1], lut[:, 2], lut[:, 3] = rgb[:, 2], rgb[:, 1], rgb[:, 0], 255

    pal = ram.put(lut.tobytes(), "palette",
                  "256-entry palette, B,G,R,A: ironbow, entries above 55 C replaced by green" if alarm else
                  "256-entry palette, 4 bytes per entry in B,G,R,A order (ironbow)")
    frame = ram.put(idx.tobytes(), "frame",
                    "160x120 sensor frame, 1 byte per pixel (identical to UC_Paletted8_Thermal)" if alarm else
                    "160x120 sensor frame, 1 byte per pixel = quantised temperature index")
    bar = ram.put(bytes(range(255, -1, -1)), "colorbar", "1x256 colour-scale bitmap: the indices 255..0")

    d.ClearColorRGB(18, 20, 26)
    d.Clear(1, 1, 1)
    d.Begin(BITMAPS)
    # thermal image: 160x120 -> 320x240 at (8, 20)
    d.BitmapHandle(0)
    d.BitmapSource(frame)
    d.BitmapLayout(PALETTED8, sw, sh)
    d.BitmapSize(BILINEAR, BORDER, BORDER, 2 * sw, 2 * sh)
    # colour bar: 1x256 indices shown 16x240 (REPEAT across the 1-byte stride)
    d.BitmapHandle(1)
    d.BitmapSource(bar)
    d.BitmapLayout(PALETTED8, 1, 256)
    d.BitmapSize(NEAREST, REPEAT, BORDER, 16, 240)
    # BITMAP_TRANSFORM_* is graphics-context state, not per handle: set it before each draw
    d.BitmapTransformA(0, 128)
    d.BitmapTransformE(0, 128)
    pal8_draw(d, pal, [(8, 20, 0, 0)])
    d.BitmapTransformA(0, 256)
    d.BitmapTransformE(0, 256 * 256 // 240)
    pal8_draw(d, pal, [(340, 20, 1, 0)])
    d.BitmapTransformE(0, 256)

    # readouts
    text8(ram, d, 8, 6, "IR-160  IRONBOW  E=0.95  9 Hz", (200, 205, 215))
    text8(ram, d, 360, 20, "%5.1fC" % tmax, (255, 255, 255))
    text8(ram, d, 360, 252, "%5.1fC" % tmin, (255, 255, 255))
    text8(ram, d, 380, 60, "SPOT", (150, 155, 165))
    text8(ram, d, 380, 72, "%4.1fC" % tspot, (255, 255, 255), scale = 2)
    text8(ram, d, 380, 110, "VALVE V-12", (150, 155, 165))
    if not alarm:
        text8(ram, d, 8, 264, "PIPE RUN B  FLANGE OK  PUMP 37C", (200, 205, 215))
    else:
        text8(ram, d, 380, 140, "ISOTHERM", (0, 255, 64))
        text8(ram, d, 380, 152, ">%4.1fC" % iso_t, (0, 255, 64))
        text8(ram, d, 8, 264, "ALARM: V-12 ABOVE ISOTHERM", (0, 255, 64))
    d.End()

    # crosshair on the spot meter
    cx, cy = 8 + 2 * spot[0], 20 + 2 * spot[1]
    d.ColorRGB(255, 255, 255)
    d.LineWidth(16)
    d.Begin(LINES)
    for (x0, y0, x1, y1) in [(cx - 14, cy, cx - 5, cy), (cx + 5, cy, cx + 14, cy),
                             (cx, cy - 14, cx, cy - 5), (cx, cy + 5, cx, cy + 14)]:
        d.Vertex2f(16 * x0, 16 * y0)
        d.Vertex2f(16 * x1, 16 * y1)
    d.End()
    return ram, d

# ----------------------------------------------------------------------------
# TEXTVGA: machine-controller setup console
# ----------------------------------------------------------------------------

def build_console():
    random.seed(SEED)
    ram, d = Ram(), DisplayList()
    cols, rows = W // 8, H // 16                       # 60 x 17 cells of 8x16

    BLK, BLU, GRN, CYN, RED, MAG, BRN, LGRY = range(8)
    DGRY, LBLU, LGRN, LCYN, LRED, LMAG, YEL, WHT = range(8, 16)
    def at(fg, bg):
        return (bg << 4) | fg
    scr = np.zeros((rows, cols, 2), dtype = np.uint8)  # (character, attribute) per cell
    scr[:, :, 0] = ord(" ")
    scr[:, :, 1] = at(LGRY, BLU)
    def put(r, c, s, attr):
        b = s.encode("cp437")
        scr[r, c:c + len(b), 0] = list(b)
        scr[r, c:c + len(b), 1] = attr
    def box(r0, c0, r1, c1, attr, title = None):
        put(r0, c0, "╔" + "═" * (c1 - c0 - 1) + "╗", attr)
        for r in range(r0 + 1, r1):
            put(r, c0, "║", attr)
            put(r, c1, "║", attr)
        put(r1, c0, "╚" + "═" * (c1 - c0 - 1) + "╝", attr)
        if title:
            put(r0, c0 + 2, " " + title + " ", at(WHT, BLU))

    put(0, 0, " SPINDLE CONTROLLER SC-400  v3.2".ljust(cols), at(WHT, CYN))
    put(0, cols - 18, "CELL 07  12:41:08 ", at(BLK, CYN))
    box(1, 0, 13, 30, at(LGRY, BLU), "Setup")
    menu = [("Spindle speed", "12000 rpm"), ("Feed override", "100 %"), ("Coolant", "ON"),
            ("Tool length ofs", "+0.125 mm"), ("Axis soft limits", "[Enter]"),
            ("Lube interval", "30 min"), ("Network", "DHCP"), ("Units", "Metric"),
            ("Language", "English")]
    sel = 1
    for i, (k, val) in enumerate(menu):
        line = " %-16s %10s " % (k, val)
        put(2 + i, 1, line, at(BLK, CYN) if i == sel else at(LGRY, BLU))
    put(12, 1, " Save & Exit".ljust(29), at(YEL, BLU))

    box(1, 31, 13, cols - 1, at(LGRY, BLU), "Status")
    status = [("Mode", "AUTO", LGRN), ("Spindle", "RUN 11985", LGRN), ("Coolant", "LOW PRESS", YEL),
              ("Motor temp", "71 C", WHT), ("Alarm", "OVERTEMP", LRED), ("Program", "O1207.NC", WHT),
              ("Parts", "0342 / 0500", WHT)]
    for i, (k, val, fg) in enumerate(status):
        put(2 + i, 33, "%-11s" % k, at(LGRY, BLU))
        put(2 + i, 45, val, at(fg, BLU))
    load = 62
    n = (load * 16 + 50) // 100
    put(10, 33, "Load", at(LGRY, BLU))
    put(10, 38, "█" * n + "░" * (16 - n), at(LGRN, BLU))
    put(10, 55, "%d%%" % load, at(WHT, BLU))
    put(11, 33, "Run time   04:17:52", at(LGRY, BLU))

    put(14, 1, "\x10 Coolant pressure low - check filter F2", at(YEL, BLU))   # 0x10 = right triangle
    put(15, 1, "  Feed override applies to all axes", at(LGRY, BLU))
    put(16, 0, " F1 Help  \x18\x19 Select  Enter Change  F10 Save  Esc Quit".ljust(cols), at(BLK, LGRY))

    src = ram.put(scr.tobytes(), "screen",
                  "60x17 cells, 2 bytes per cell: CP437 character, then attribute (bg << 4) | fg")
    d.Clear(1, 1, 1)
    d.BlendFunc(ONE, ZERO)          # TEXTVGA background pixels have alpha 0: write them anyway
    d.Begin(BITMAPS)
    d.BitmapHandle(0)
    d.BitmapSource(src)
    d.BitmapLayout(TEXTVGA, 2 * cols, rows)
    d.BitmapSize(NEAREST, BORDER, BORDER, W, H)
    d.Vertex2ii(0, 0, 0, 0)
    return ram, d

# ----------------------------------------------------------------------------
# TEXT8X8: CAN-bus monitor log
# ----------------------------------------------------------------------------

def build_canlog():
    random.seed(SEED)
    ram, d = Ram(), DisplayList()
    RING = 64                       # rows and bytes per row: powers of two for REPEAT
    VIS = 30                        # visible log rows: y = 24 .. 263
    head = 10                       # next row to write: the window wraps from row 44 to row 9

    green, yellow, red = (60, 230, 110), (255, 205, 0), (255, 70, 60)
    ids = [("18FEF100", "EngSpd %4d"), ("0CF00400", "Torque %3d%%"), ("18FEEE00", "Cool %3dC"),
           ("18FEF200", "Fuel %3.1fL/h"), ("0C000003", "TSC1 req")]
    ring = np.full((RING, RING), ord(" "), dtype = np.uint8)
    colours = {}
    t = 8.1000
    for k in range(RING):
        row = (head - RING + k) % RING              # oldest first, newest at head-1
        t += random.uniform(0.0004, 0.0031)
        if k % 23 == 17:
            s = "%07.4f -------- ERROR FRAME  stuff error  TEC=%d" % (t, 90 + k % 7)
            colours[row] = red
        else:
            cid, dec = ids[k % len(ids)]
            data = [random.randrange(256) for i in range(8)]
            val = {0: 1850 + k * 3, 1: 30 + k % 40, 2: 88 + k % 5, 3: 11.0 + (k % 9) / 10.0, 4: 0}[k % 5]
            s = "%07.4f %s 8 %s %s" % (t, cid, " ".join("%02X" % b for b in data),
                                        dec % val if "%" in dec else dec)
            if k % 11 == 6:
                s += " RETX"
                colours[row] = yellow
        b = s[:60].encode("cp437")
        ring[row, :len(b)] = list(b)
    first = (head - VIS) % RING
    log = ram.put(ring.tobytes(), "ring",
                  "64x64-byte ring buffer: 64 log lines of 64 characters, 1 byte per 8x8 cell")

    d.ClearColorRGB(8, 12, 10)
    d.Clear(1, 1, 1)
    # header and footer bars
    d.ColorRGB(200, 210, 205)
    d.Begin(RECTS)
    d.Vertex2ii(0, 0, 0, 0)
    d.Vertex2ii(W, 10, 0, 0)
    d.Vertex2ii(0, 264, 0, 0)
    d.Vertex2ii(W, 272, 0, 0)
    d.End()
    d.Begin(BITMAPS)
    text8(ram, d, 4, 1, "CAN1 500k  RX 1832/s  ERR 3  LOAD 37%  [LIVE]", (0, 0, 0))
    text8(ram, d, 0, 13, "  TIME    ID      L DATA                    DECODE", (90, 200, 255))
    text8(ram, d, 4, 264, "F1 PAUSE  F2 FILTER  F3 MARK  F4 SAVE  F9 BUS", (0, 0, 0))

    # the log window: one bitmap, scrolled by BITMAP_TRANSFORM_F
    d.BitmapHandle(0)
    d.BitmapSource(log)
    d.BitmapLayout(TEXT8X8, RING, RING)
    d.BitmapSize(NEAREST, REPEAT, REPEAT, W, 8 * VIS)
    d.BitmapTransformF(first * 8 * 256)
    d.ColorRGB(*green)
    d.Vertex2ii(0, 24, 0, 0)
    for k in range(VIS):            # re-draw error / retransmit lines in colour, one line each
        row = (first + k) % RING
        if row in colours:
            d.ScissorXY(0, 24 + 8 * k)
            d.ScissorSize(W, 8)
            d.ColorRGB(*colours[row])
            d.Vertex2ii(0, 24, 0, 0)
    d.ScissorXY(0, 0)
    d.ScissorSize(W, H)
    d.BitmapTransformF(0)
    return ram, d

# ----------------------------------------------------------------------------
# BARGRAPH: audio spectrum analyser
# ----------------------------------------------------------------------------

def build_spectrum():
    random.seed(SEED)
    ram, d = Ram(), DisplayList()

    centres = ["20", "25", "31", "40", "50", "63", "80", "100", "125", "160", "200", "250", "315",
               "400", "500", "630", "800", "1k", "1k2", "1k6", "2k", "2k5", "3k1", "4k", "5k",
               "6k3", "8k", "10k", "12k", "16k", "20k"]
    nb = len(centres)
    X0, Y0, BH = 44, 24, 150                    # spectrum origin and height in pixels
    BW, GAP = 12, 2
    shape = np.interp(np.arange(nb), [0, 5, 12, 20, 30], [-20, -7, -14, -22, -42])
    db = np.clip(shape + np.array([random.uniform(-4, 4) for i in range(nb)]), -59, -1)
    db[5] = db[6] = -3.0                        # kick drum at 63-80 Hz reaches the red zone
    h = np.round((db + 60) / 60 * BH).astype(int)
    peak = np.minimum(h + np.array([random.randrange(4, 15) for i in range(nb)]), BH)

    cols = np.full(nb * (BW + GAP), 255, dtype = np.uint8)          # 255 = empty column
    for b in range(nb):
        cols[b * (BW + GAP):b * (BW + GAP) + BW] = 255 - h[b]       # drawn where texel row > value
    spec = ram.put(cols.tobytes(), "spectrum",
                   "434 columns, 1 byte each = 255 - bar height (31 bands x (12 px bar + 2 px gap))")

    HR, HH, HY = 512, 60, 202                   # history ring columns, strip height, strip top
    lvl = np.zeros(HR)
    x = 30.0
    for i in range(HR):
        x = min(HH - 1, max(2, x + random.uniform(-4, 4) + (32 - x) * 0.05))
        lvl[i] = x
    hist = ram.put((255 - np.round(lvl)).astype(np.uint8).tobytes(), "history",
                   "512-column level-history ring, 1 byte per column = 255 - level")
    hhead = 300                                 # oldest visible column

    d.ClearColorRGB(14, 14, 18)
    d.Clear(1, 1, 1)
    # dB grid
    d.ColorRGB(48, 50, 58)
    d.LineWidth(8)
    d.Begin(LINES)
    for k in range(7):
        y = Y0 + BH - k * BH // 6
        d.Vertex2f(16 * X0, 16 * y)
        d.Vertex2f(16 * (X0 + nb * (BW + GAP)), 16 * y)
    d.End()

    d.Begin(BITMAPS)
    d.BitmapHandle(0)
    d.BitmapSource(spec)
    d.BitmapLayout(BARGRAPH, nb * (BW + GAP), 1)
    d.BitmapSize(NEAREST, BORDER, BORDER, nb * (BW + GAP), BH)
    d.BitmapTransformF((256 - BH) * 256)        # screen rows map to texel rows 106..255
    zones = [(Y0, 15, (255, 60, 50)), (Y0 + 15, 30, (255, 200, 0)), (Y0 + 45, BH - 45, (40, 220, 90))]
    for (zy, zh, rgb) in zones:                 # red / yellow / green: same bitmap, 3 scissors
        d.ScissorXY(0, zy)
        d.ScissorSize(W, zh)
        d.ColorRGB(*rgb)
        d.Vertex2ii(X0, Y0, 0, 0)
    d.ScissorXY(0, 0)
    d.ScissorSize(W, H)
    d.BitmapTransformF(0)

    # history strip: ring buffer scrolled with BITMAP_TRANSFORM_C
    d.BitmapHandle(1)
    d.BitmapSource(hist)
    d.BitmapLayout(BARGRAPH, HR, 1)
    d.BitmapSize(NEAREST, REPEAT, BORDER, W, HH)
    d.BitmapTransformC(hhead * 256)
    d.BitmapTransformF((256 - HH) * 256)
    d.ColorRGB(70, 170, 255)
    d.Vertex2ii(0, HY, 1, 0)
    d.BitmapTransformC(0)
    d.BitmapTransformF(0)

    # labels
    text8(ram, d, 4, 4, "RTA  1/3 OCT  48kHz  A-WT", (220, 220, 230))
    text8(ram, d, 388, 4, "PEAK HOLD", (255, 255, 255))
    for k in range(7):
        s = "%d" % (-10 * k)
        text8(ram, d, X0 - 6 - 8 * len(s), Y0 + k * BH // 6 - 4, s, (140, 142, 155))
    for b in (2, 5, 8, 11, 14, 17, 20, 23, 26, 29):
        s = centres[b]
        cx = X0 + b * (BW + GAP) + BW // 2
        text8(ram, d, cx - 4 * len(s), Y0 + BH + 4, s, (140, 142, 155))
    text8(ram, d, 4, HY - 12, "LEVEL HISTORY  60 s", (140, 142, 155))
    text8(ram, d, 4, 264, "LEQ 74.2 dBA  LMAX 91.0  CLIP 0", (220, 220, 230))
    d.End()

    # peak-hold markers
    d.ColorRGB(255, 255, 255)
    d.Begin(RECTS)
    for b in range(nb):
        x = X0 + b * (BW + GAP)
        y = Y0 + BH - peak[b]
        d.Vertex2f(16 * x, 16 * y)
        d.Vertex2f(16 * (x + BW), 16 * (y + 2))
    d.End()
    return ram, d

# ----------------------------------------------------------------------------
# Projects
# ----------------------------------------------------------------------------

PROJECTS = [
    dict(name = "UC_Paletted8_Thermal", build = lambda: build_thermal(False),
         title = "PALETTED8: handheld thermal camera inspecting steam valve V-12 (ironbow palette)",
         tags = ["BT815", "bitmap", "PALETTED8", "PALETTE_SOURCE", "COLOR_MASK", "TEXT8X8", "use case"],
         notes = ["PALETTED8 outputs ONE palette byte per draw, so each image is drawn 4 times:",
                  "COLOR_MASK selects the channel and PALETTE_SOURCE = palette + byte offset.",
                  "BILINEAR filtering happens after the palette lookup: the 2x zoom blends colours, not indices.",
                  "The colour bar is itself PALETTED8, so it can never disagree with the image.",
                  "Isotherm alarm: see UC_Paletted8_Thermal_Alarm. frame.raw is byte-identical; only palette.raw changes."]),
    dict(name = "UC_Paletted8_Thermal_Alarm", build = lambda: build_thermal(True),
         title = "PALETTED8: same thermal frame with a >55 C isotherm alarm (only the 1 KB palette changed)",
         tags = ["BT815", "bitmap", "PALETTED8", "PALETTE_SOURCE", "COLOR_MASK", "TEXT8X8", "use case"],
         notes = ["Compare with UC_Paletted8_Thermal: frame.raw and colorbar.raw are identical.",
                  "The isotherm is painted purely by rewriting a slice of palette.raw;",
                  "the display list differs only in the alarm labels."]),
    dict(name = "UC_TextVGA_Console", build = build_console,
         title = "TEXTVGA: setup console of a CNC spindle controller (legacy VGA text-mode HMI retrofit)",
         tags = ["BT815", "bitmap", "TEXTVGA", "use case"],
         notes = ["The whole 480x272 screen is ONE 2,040-byte bitmap and ONE vertex.",
                  "Cell (row, col) is at screen + 2 * (60 * row + col): char byte, then attribute byte.",
                  "TEXTVGA background pixels have alpha 0, so BLEND_FUNC(ONE, ZERO) writes them as-is.",
                  "Box frames, the load bar and the arrows come from the CP437 ROM font."]),
    dict(name = "UC_Text8x8_CANLog", build = build_canlog,
         title = "TEXT8X8: CAN-bus (J1939) monitor with a scrolling 64-line ring-buffer log",
         tags = ["BT815", "bitmap", "TEXT8X8", "BITMAP_TRANSFORM_F", "SCISSOR", "use case"],
         notes = ["The log window is one 64x64 TEXT8X8 bitmap with REPEAT in x and y.",
                  "BITMAP_TRANSFORM_F(first_row * 8 * 256) picks the first visible line: scrolling",
                  "costs one DL word and no memory copy; the window wraps through the ring.",
                  "Error / retransmit lines are re-drawn red / yellow under a one-line scissor",
                  "(SCISSOR_XY + SCISSOR_SIZE + COLOR_RGB + VERTEX2II = 4 DL words per coloured line).",
                  "If you change TRANSFORM_F by hand, the colour scissors no longer follow their lines."]),
    dict(name = "UC_Bargraph_Spectrum", build = build_spectrum,
         title = "BARGRAPH: 31-band 1/3-octave audio spectrum analyser with peak hold and level history",
         tags = ["BT815", "bitmap", "BARGRAPH", "SCISSOR", "BITMAP_TRANSFORM_C", "BITMAP_TRANSFORM_F", "use case"],
         notes = ["BARGRAPH: one byte per pixel column; the pixel is drawn where its texel row > the byte.",
                  "BITMAP_TRANSFORM_F((256 - 150) * 256) maps the 150 screen rows to texel rows 106..255.",
                  "Green / yellow / red VU zones = the same bitmap drawn 3 times under 3 scissors.",
                  "History strip: REPEAT in x, scrolled by BITMAP_TRANSFORM_C(oldest_column * 256)."]),
]

def coprocessor(p, assets, d, device):
    L = ["// " + "=" * 76,
         "// " + p["title"],
         "// %dx%d, %s. Data in resources/*.raw, built by make_assets.py (see README.md)." % (W, H, device),
         "// " + "=" * 76,
         "// RAM_G map (Content tab, loaded from resources/):"]
    for (nm, a, b, desc) in assets:
        L.append("//   0x%06x  %-13s %6d B  %s" % (a, nm + ".raw", len(b), desc))
    L.append("//")
    L += ["// " + s for s in p["notes"]]
    L += ["// " + "=" * 76, ""]
    return L + d.lines(dict((a, nm) for (nm, a, b, desc) in assets if nm != "labels"), DEVICES[device][1])

def ese(lines, assets, device):
    return {
        "content": [{
            "compressed": False,
            "dataStorage": "Embedded",
            "destName": "content/" + nm,
            "displayName": nm + ".raw",
            "fileType": "Raw",
            "memoryAddress": a,
            "memoryLoaded": True,
            "sourcePath": "resources/" + nm + ".raw",
        } for (nm, a, b, desc) in assets],
        "coprocessor": lines,
        "project": {"device": DEVICES[device][0], "flash_size": 0},
        "registers": {"REG_FREQUENCY": 60000000, "REG_HSIZE": W, "REG_ROTATE": 0, "REG_VSIZE": H,
                      "macro": ["NOP()", "NOP()"]},
    }

def build_all(outdir = HERE, device = DEFAULT_DEVICE):
    for p in PROJECTS:
        ram, d = p["build"]()
        assets = ram.assets()
        pdir = os.path.join(outdir, p["name"])
        for sub in ("resources", "overview"):
            os.makedirs(os.path.join(pdir, sub), exist_ok = True)
        for (nm, a, b, desc) in assets:
            with open(os.path.join(pdir, "resources", nm + ".raw"), "wb") as f:
                f.write(b)
        with open(os.path.join(pdir, p["name"] + ".ese"), "w", encoding = "utf-8") as f:
            json.dump(ese(coprocessor(p, assets, d, device), assets, device), f, indent = 4)
            f.write("\n")
        tags = [device if t == DEFAULT_DEVICE else t for t in p["tags"]]
        with open(os.path.join(pdir, "overview", "overview.json"), "w", encoding = "utf-8") as f:
            json.dump([{"project_name": p["name"], "description": p["title"], "tags": tags}], f)
        # the screen is the same on every device: reuse the shipped thumbnail
        thumb = os.path.join(HERE, p["name"], "overview", p["name"] + ".png")
        dst = os.path.join(pdir, "overview", p["name"] + ".png")
        if os.path.exists(thumb) and os.path.abspath(thumb) != os.path.abspath(dst):
            shutil.copyfile(thumb, dst)
        ncmd = sum(1 for it in d.items if it[0] == "cmd")
        print("%-28s %3d DL commands  %6d B RAM_G in %d files  -> %s"
              % (p["name"], ncmd, sum(len(b) for (_, _, b, _) in assets), len(assets), pdir))

if __name__ == "__main__":
    ap = argparse.ArgumentParser(description = "Build the bitmap use-case EVE Screen Editor projects.")
    ap.add_argument("--device", default = DEFAULT_DEVICE, choices = sorted(DEVICES),
                    help = "target EVE device (default %(default)s)")
    ap.add_argument("--out", help = "output folder (default: this folder for %s, ./<DEVICE> otherwise)"
                    % DEFAULT_DEVICE)
    a = ap.parse_args()
    out = a.out or (HERE if a.device == DEFAULT_DEVICE else os.path.join(HERE, a.device))
    build_all(out, a.device)
